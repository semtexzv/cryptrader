#![feature(box_syntax,await_macro,async_await)]
#![allow(unused_mut, unused_variables, unused_parens, unused_imports, non_snake_case, dead_code)]

mod prelude;
pub mod bitfinex;
pub mod binance;

