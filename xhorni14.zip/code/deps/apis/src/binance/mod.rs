use crate::prelude::*;
pub mod rest;

pub static API_BASE : &str = "https://api.binance.com";
