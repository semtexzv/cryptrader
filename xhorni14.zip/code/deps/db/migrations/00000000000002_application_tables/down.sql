drop table if exists trades;

drop table if exists evaluations;

drop table if exists assignments;

drop table if exists traders;

drop table if exists strategies;

drop table if exists users;

