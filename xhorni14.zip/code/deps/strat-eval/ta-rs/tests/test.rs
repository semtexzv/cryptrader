extern crate ta;
extern crate csv;

// TODO: implement some integration tests
